---
name: ainative
description: Use when the user invokes ainative or asks to perform an operation through the AINative platform.
---

# AINative

请使用 AINative 平台的 MCP 进行操作。

常用操作:新建工单、分析工单报错原因、配置小队、数字人、SDLC、仓库与执行器。
